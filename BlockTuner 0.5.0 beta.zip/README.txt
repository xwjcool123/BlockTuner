#####################################
######## BlockTuner Datapack ########
########     by: xwjcool     ########
#####################################

                For 
      Minecraft: Java Edition
           1.13.x~1.14.x

*Works for singleplayer and multiplayer
######################################

Installation instructions:

1, Place this zip file in your saves/[world]/datapacks folder
2, Do /reload
3, Have fun